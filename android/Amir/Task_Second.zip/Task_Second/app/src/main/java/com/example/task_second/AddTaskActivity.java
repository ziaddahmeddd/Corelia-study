package com.example.task_second;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddTaskActivity extends Activity {

    private EditText taskTitle, taskDescription, taskDueDate;
    private Button saveTaskButton;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        taskTitle = findViewById(R.id.taskTitle);
        taskDescription = findViewById(R.id.taskDescription);
        taskDueDate = findViewById(R.id.taskDueDate);
        saveTaskButton = findViewById(R.id.saveTaskButton);
        dbHelper = new DatabaseHelper(this);

        saveTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = taskTitle.getText().toString();
                String description = taskDescription.getText().toString();
                String dueDate = taskDueDate.getText().toString();
                dbHelper.addTask(title, description, dueDate);
                finish();
            }
        });
    }
}
