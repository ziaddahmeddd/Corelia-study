package com.example.task_second;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity implements TasksAdapter.OnItemClickListener{

    private DatabaseHelper dbHelper;
    private ListView taskListView;
    private Button addTaskButton;
    private ArrayList<String> taskList;
    private ArrayAdapter<String> taskAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        taskListView = findViewById(R.id.taskListView);
        addTaskButton = findViewById(R.id.addTaskButton);

        taskList = new ArrayList<>();
        taskAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskList);
        taskListView.setAdapter(taskAdapter);
        TasksAdapter tasksAdapter = new TasksAdapter(taskList, this);
        loadTasks();

        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
                startActivity(intent);
            }
        });

//        taskListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                // Handle item click for editing tasks
//            }
//        });


        Intent serviceIntent = new Intent(this, TaskReminderService.class);
        startService(serviceIntent);
    }


    @Override
    protected void onResume() {
        super.onResume();
        loadTasks();
    }
    @Override
    public void onItemClick(Task task) {
        // Handle the item click event here
        String description = task.getDescription();
        String dueDate = task.getDueDate();

        // You can display the description and dueDate in a dialog, Toast, or any other way you prefer
        Toast.makeText(this, "Description: " + description + "\nDue Date: " + dueDate, Toast.LENGTH_SHORT).show();
    }
    private void loadTasks() {
        taskList.clear();
        Cursor cursor = dbHelper.getAllTasks();
        if (cursor.moveToFirst()) {
            do {
                String taskTitle = cursor.getString(cursor.getColumnIndex("title"));
                taskList.add(taskTitle);
            } while (cursor.moveToNext());
        }
        cursor.close();
        taskAdapter.notifyDataSetChanged();
    }


}


