package com.example.task_second;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TaskReminderService extends Service {

    private static final String TAG = "TaskReminderService";
    private Handler handler;
    private DatabaseHelper dbHelper;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler();
        dbHelper = new DatabaseHelper(this);

        startCheckingForReminders();
    }

    private void startCheckingForReminders() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                checkForReminders();
                handler.postDelayed(this, 60000); // Check every minute
            }
        }, 60000); // Initial delay
    }

    private void checkForReminders() {
        Cursor cursor = dbHelper.getAllTasks();
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
                @SuppressLint("Range") String dueDate = cursor.getString(cursor.getColumnIndex("due_date"));

                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    Date due = sdf.parse(dueDate);
                    Date now = new Date();

                    if (due != null && due.before(now)) {
                        // Due date has passed
                        NotificationHelper notificationHelper = new NotificationHelper(this);
                        notificationHelper.sendNotification("Task Reminder", "Task '" + title + "' is due!");
                    }
                } catch (ParseException e) {
                    Log.e(TAG, "Date parsing error", e);
                }

            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
