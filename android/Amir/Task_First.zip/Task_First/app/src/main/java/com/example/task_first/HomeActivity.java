package com.example.task_first;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    private TextView textViewWelcomeMessage;
    private Button buttonSignOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        textViewWelcomeMessage = findViewById(R.id.textViewWelcomeMessage);
        buttonSignOut = findViewById(R.id.buttonSignOut);

        // Get the username from the login page
        SharedPreferences preferences = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        String username = preferences.getString("username", "");

        // Set the welcome message
        String welcomeMessage = "Welcome, " + username + "!";
        textViewWelcomeMessage.setText(welcomeMessage);

        buttonSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to the login page upon sign out
                Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();  // Close the welcome activity to prevent going back to it on sign out
            }
        });
    }
}