﻿using Microsoft.Win32;

public static class RegistryHelper
{
    private const string RegistryKey = @"SOFTWARE\YourAppName"; // Adjust this key as per your application

    public static void SaveLoginInformation(string username, string password)
    {
        // Save login information securely in the registry
        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(RegistryKey))
        {
            key.SetValue("Username", username);
            // Example: Store password securely (not recommended to store plaintext passwords)
            // Instead, consider using secure methods or alternative authentication mechanisms
            // For demonstration only: Storing password as plaintext for simplicity
            key.SetValue("Password", password);
        }
    }

    public static void ClearLoginInformation()
    {
        // Clear stored login information from the registry
        using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RegistryKey, true))
        {
            if (key != null)
            {
                key.DeleteValue("Username", false); // Delete username value
                key.DeleteValue("Password", false); // Delete password value
            }
        }
    }

    public static string GetSavedUsername()
    {
        // Retrieve saved username from the registry
        using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RegistryKey))
        {
            return key?.GetValue("Username")?.ToString();
        }
    }

    public static string GetSavedPassword()
    {
        // Retrieve saved password from the registry
        using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RegistryKey))
        {
            return key?.GetValue("Password")?.ToString();
        }
    }
}
