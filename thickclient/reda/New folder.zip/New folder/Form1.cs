﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp_555
{
    public partial class Form1 : Form
    {
        private Button loginButton;
        private Button registerButton;

        public Form1()
        {
            InitializeComponent();
            // Wire up click events after initializing components
            loginButton.Click += loginButton_Click;
            registerButton.Click += registerButton_Click;
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            // Open login form
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            // Open registration form
            RegistrationForm registrationForm = new RegistrationForm();
            registrationForm.Show();
        }

        private void InitializeComponent()
        {
            this.loginButton = new System.Windows.Forms.Button();
            this.registerButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // loginButton
            // 
            this.loginButton.Location = new System.Drawing.Point(453, 87);
            this.loginButton.Name = "loginButton";
            this.loginButton.Size = new System.Drawing.Size(125, 33);
            this.loginButton.TabIndex = 0;
            this.loginButton.Text = "Login";
            this.loginButton.UseVisualStyleBackColor = true;
            // 
            // registerButton
            // 
            this.registerButton.Location = new System.Drawing.Point(452, 159);
            this.registerButton.Name = "registerButton";
            this.registerButton.Size = new System.Drawing.Size(126, 36);
            this.registerButton.TabIndex = 1;
            this.registerButton.Text = "Register";
            this.registerButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1014, 425);
            this.Controls.Add(this.registerButton);
            this.Controls.Add(this.loginButton);
            this.Name = "Form1";
            this.ResumeLayout(false);

        }
    }
}
