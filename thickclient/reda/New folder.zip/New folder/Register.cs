﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp_555
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;
            string email = emailTextBox.Text;

            // Example validation (replace with your actual validation logic)
            if (IsValidRegistration(username, password, email))
            {
                MessageBox.Show("Registration successful!");
                // Optionally, save login information
                RegistryHelper.SaveLoginInformation(username, password);

                // Open the login form or main application form
                LoginForm loginForm = new LoginForm();
                loginForm.Show();

                // Close the registration form
                this.Close();
            }
            else
            {
                MessageBox.Show("Please fill in all fields.");
            }
        }

        private bool IsValidRegistration(string username, string password, string email)
        {
            // Replace with actual validation logic (e.g., database check)
            // For demonstration purposes, just check if fields are not empty
            return (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(email));
        }
    }
}
