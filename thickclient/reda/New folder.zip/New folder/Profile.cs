﻿using System;
using System.Windows.Forms;
using WindowsFormsApp_555;

namespace YourAppName
{
    public partial class ProfileForm : Form
    {
        public ProfileForm()
        {
            InitializeComponent();
        }

        private void ProfileForm_Load(object sender, EventArgs e)
        {
            // Example: Load user profile information when form loads
            string username = RegistryHelper.GetSavedUsername();
            string password = RegistryHelper.GetSavedPassword();

            // Example: Load user profile data from database
            UserProfile userProfile = DatabaseHelper.GetUserProfile(username);

            if (userProfile != null)
            {
                // Display profile information in UI controls
                usernameLabel.Text = userProfile.Username;
                emailLabel.Text = userProfile.Email;
                // Add more fields as per your UserProfile class
            }
            else
            {
                MessageBox.Show("Failed to load profile.");
            }
        }

        private void logoutButton_Click(object sender, EventArgs e)
        {
            // Example: Clear saved login information from registry on logout
            RegistryHelper.ClearLoginInformation();

            // Close the profile form and show the login form again
            this.Close();
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
        }
    }
}
