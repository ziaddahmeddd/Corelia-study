﻿using System;
using System.Windows.Forms;
using YourAppName;

namespace WindowsFormsApp_555
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string username = usernameTextBox.Text;
            string password = passwordTextBox.Text;

            // Example validation (replace with your actual validation logic)
            if (IsValidLogin(username, password))
            {
                MessageBox.Show("Login successful!");
                // Optionally, save login information
                RegistryHelper.SaveLoginInformation(username, password);

                // Open the profile form or main application form
                ProfileForm profileForm = new ProfileForm();
                profileForm.Show();

                // Close the login form
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.");
            }
        }

        private bool IsValidLogin(string username, string password)
        {
            // Replace with actual validation logic (e.g., database check)
            // For demonstration purposes, hardcoded validation
            return (username == "admin" && password == "password");
        }
    }
}
